/**
 * models a list of houses read from a file to be compared against specific criteria
 * 
 * @author Marina DelVecchio 
 * @version October 4, 2021
 */
package Project1;
import java.util.*;
import java.io.*;

public class HouseList {
	//-------------------------------------------------------------------------
	//input list of houses from file
	ArrayList <House> houseList;
	
	//-------------------------------------------------------------------------
	/**
	 * The constructor
	 * @param fileName: a String representing the name of the file containing houses that will be entered into array list
	 */
	public HouseList(String fileName) {
		houseList = new ArrayList<>();
		String tempA;
		int tempP;
		int tempAr;
		int tempNB;
		Scanner myFileIn = null;
		try {
			myFileIn = new Scanner(new File(fileName));
		} catch(FileNotFoundException e) {
			System.out.println("File not found.");
			System.exit(1);
		}
		while(myFileIn.hasNext()) {
			tempA = myFileIn.next();
			tempP = myFileIn.nextInt();
			tempAr = myFileIn.nextInt();
			tempNB = myFileIn.nextInt();
			houseList.add(new House(tempA, tempP, tempAr, tempNB));
		}
		myFileIn.close();
	}
	//-------------------------------------------------------------------------
	/**
	 * a method to print the houses in the list that match the given criteria
	 * @param c: a Criteria object
	 */
	public void printHouses(Criteria c) {
		System.out.println(getHouses(c));
	}
	//-------------------------------------------------------------------------
	/**
	 * a method to determine which houses in the list satisfy the given criteria
	 * @param c: a Criteria object
	 * @return String: a concatenated list of all houses that match the given criteria
	 */
	public String getHouses(Criteria c) {
		String houses="";
		for(House h: houseList) {
			if(h.satisfies(c))
				houses+="\n--------------------------------------------------------------------------------------------------\n"+h.toString();
		}
		return houses;
	}
}