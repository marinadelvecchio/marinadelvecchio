/**
 * models a criteria to be used when searching for a house with specific features
 * 
 * @author Marina DelVecchio 
 * @version October 4, 2021
 */
package Project1;

public class Criteria {
	//----------------------------------------------------------------------------------
	//input minimum price in dollars any house can be
	private int minimumPrice;
	
	//----------------------------------------------------------------------------------
	//input maximum price in dollars any house can be
	private int maximumPrice;
	
	//----------------------------------------------------------------------------------
	//input minimum area in square feet any house can have
	private int minimumArea;
	
	//----------------------------------------------------------------------------------
	//input maximum area in square feet any house can have
	private int maximumArea;
	
	//----------------------------------------------------------------------------------
	//input minimum number of bedrooms any house can have
	private int minimumNumberOfBedrooms;
	
	//----------------------------------------------------------------------------------
	//input maximum number of bedrooms any house can have
	private int maximumNumberOfBedrooms;
	
	//----------------------------------------------------------------------------------
	/**
	 * The constructor
	 * @param minP: an int representing the minimum price
	 * @param maxP: an int representing the maximum price
	 * @param minA: an int representing the minimum area
	 * @param maxA: an int representing the maximum area
	 * @param minNB: an int representing the minimum number of bedrooms
	 * @param maxNB: an int representing the maximum number of bedrooms
	 */
	public Criteria(int minP, int maxP, int minA, int maxA, int minNB, int maxNB) {
		minimumPrice = minP;
		maximumPrice = maxP;
		minimumArea = minA;
		maximumArea = maxA;
		minimumNumberOfBedrooms = minNB;
		maximumNumberOfBedrooms = maxNB;
	}
	//----------------------------------------------------------------------------------
	public int getMinimumPrice() {
		return minimumPrice;
	}
	//----------------------------------------------------------------------------------
	public int getMaximumPrice() {
		return maximumPrice;
	}
	//----------------------------------------------------------------------------------
	public int getMinimumArea() {
		return minimumArea;
	}
	//----------------------------------------------------------------------------------
	public int getMaximumArea() {
		return maximumArea;
	}
	//----------------------------------------------------------------------------------
	public int getMinimumNumberOfBedrooms() {
		return minimumNumberOfBedrooms;
	}
	//----------------------------------------------------------------------------------
	public int getMaximumNumberOfBedrooms() {
		return maximumNumberOfBedrooms;
	}
}