/**
 * a tester class for the class HouseList, which incorporates the classes House 
 * and Criteria
 * 
 * @author Marina DelVecchio 
 * @version October 4, 2021
 */
package Project1;
import java.util.*;

public class HouseListTester {
	//------------------------------------------------------------------------------------------------------------------------------
	//input house list that will be constructed from specified file
	private static HouseList availableHouses;
	
	//------------------------------------------------------------------------------------------------------------------------------
	/**
	 * Main method
	 * @param args
	 */
	public static void main(String[] args) {
		//calls HouseList constructor with parameter "houses.txt"
		availableHouses = new HouseList("houses.txt");
		//creates Scanner object to read file
		Scanner in = new Scanner(System.in);
		//variable to determine if while loop should continue
		String repeat = "y";
		//temporary variables to use while reading file before a Criteria object is constructed
		int tempMinPrice;
		int tempMaxPrice;
		int tempMinArea;
		int tempMaxArea;
		int tempMinBeds;
		int tempMaxBeds;
		//continues until user indicates they don't wish to enter any more criteria
		while(repeat.equalsIgnoreCase("y")) {
			//gets input criteria from user and storing in temporary variables
			System.out.print("Enter minimum price: ");
			tempMinPrice = in.nextInt();
			System.out.print("Enter maximum price: ");
			tempMaxPrice = in.nextInt();
			System.out.print("Enter minimum area: ");
			tempMinArea = in.nextInt();
			System.out.print("Enter maximum area: ");
			tempMaxArea = in.nextInt();
			System.out.print("Enter minimum number of bedrooms: ");
			tempMinBeds = in.nextInt();
			System.out.print("Enter maximum number of bedrooms: ");
			tempMaxBeds = in.nextInt();
			//constructs a Criteria object with temporary variables and prints houses that meet given criteria
			availableHouses.printHouses(new Criteria(tempMinPrice, tempMaxPrice, tempMinArea, tempMaxArea, tempMinBeds, tempMaxBeds));
			//determines if user would like to enter another set of criteria
			System.out.print("Would you like to enter new criteria? (enter y to continue) "); 
			repeat = in.next();
		}
		//closes Scanner object
		in.close();
	}
}