public class RealProject {
    public static void main(String[] args) {
        for(int i = 0; i<10000000; i++){
             double sinValue = Math.sin(i);
             double y_value = i* Math.abs(sinValue);
             //replace with your interval 
             //calculating interval [1,2]
             if(y_value>=40 && y_value<=41){
                 System.out.println(i);
             }
         }
     }
}
