
/**
 * To test inequalities on the sequence of prime numbers
 *
 * Marina DelVecchio
 * 4/15/23
 */
public class RealProject
{
    public static void main(String[] args) {
        proj_1();
    }
    
    //checks 1<=n<=6 for first inequality
    public static void ineq_1() {
        int[] primes = generate_Primes(10);
        for(int i = 1; i<7; i++){
            double left = Math.sqrt(primes[i+1])+Math.sqrt(primes[i+2]);
            double right = Math.sqrt((primes[i]+primes[i+3]));
            System.out.println("n="+i+": "+left+" < "+right);
            System.out.println(left<right);
        }
    }
    
    //checks 1<=n<=99 for the third inequality
    public static void ineq_3() {
        int[]primes = generate_Primes(106);
        for(int i=1; i<100; i++) {
            double left = Math.sqrt(primes[i+3])+Math.sqrt(primes[i+4]);
            double right = Math.sqrt((primes[i]+primes[i+1]+primes[i+2]+primes[i+5]));
            System.out.println("n="+i+": "+left+" < "+right);
            System.out.println(left<right);
        }
    }
    
    //checks 1<=n<=9999 for fourth inequality
    public static void ineq_4() {
        int[] primes = generate_Primes(10006);
        for(int i=1; i<10000; i++) {
            double left = Math.sqrt(primes[i+4])+Math.sqrt(primes[i+5]);
            double right = Math.sqrt((primes[i]+primes[i+1]+primes[i+2]+primes[i+3]+primes[i+6]));
            System.out.println("n="+i+": "+left+" < "+right);
            System.out.println(left<right);
        }
    }
    
    public static void proj_1() {
        double [] primes = dgenerate_Primes(110);
        for(int i=1; i<101; i++) {
            double result = Math.pow((primes[i+2]/primes[i+1]), 4)-Math.pow((primes[i+1]/primes[i]), 4);
            System.out.println("n="+i+": "+result);
        }
    }
    
    //generates a list of prime integer numbers of length n
    public static int[]generate_Primes(int n) {
        int[] primes = new int[n];
        primes[0]=-1;
        primes[1]=2;
        //number we are checking to see if it is prime
        int i=3;
        //to keep track if i has any factors
        int k=1;
        //index counter
        int in=2;
        while(primes[n-1]==0) {
            //only need to check numbers <= square root of i
            for(int j=2; j*j<=i; j++) {
                if(i%j==0) {
                    k=-1;
                }
            }
            if(k==1){
                primes[in]=i;
                in++;
            }
            //only odd numbers can be prime
            i=i+2;
            //reset tracker
            k=1;
        }
        return primes;
    }
    
    //generates a list of prime double numbers of length n
    public static double[]dgenerate_Primes(int n) {
        double[] primes = new double[n];
        primes[0]=-1;
        primes[1]=2;
        //number we are checking to see if it is prime
        int i=3;
        //to keep track if i has any factors
        int k=1;
        //index counter
        int in=2;
        while(primes[n-1]==0) {
            //only need to check numbers <= square root of i
            for(int j=2; j*j<=i; j++) {
                if(i%j==0) {
                    k=-1;
                }
            }
            if(k==1){
                primes[in]=i;
                in++;
            }
            //only odd numbers can be prime
            i=i+2;
            //reset tracker
            k=1;
        }
        return primes;
    }

}
