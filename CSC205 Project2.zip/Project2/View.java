/**
 * an abstract class to serve as a parent class to any child view classes as necessary
 * 
 * @author Marina DelVecchio
 * @version November 2021
 */

// system imports 
import java.util.Properties; 
import java.util.Vector; 
import java.util.EventObject; 
import javafx.scene.Group; 

public abstract class View extends Group 
{ 
    //-------------------------------------------------------------------------
    //used to specify class name of child class
    private String myClassName; 

    //-------------------------------------------------------------------------
    /**
     * the constructor
     * @param classname: a String object
     */
    public View(String classname) 
    { 
        myClassName = classname; 
    } 
    //-------------------------------------------------------------------------
    public abstract void updateState(String key, Object value); 
    //-------------------------------------------------------------------------
    public abstract void displayErrorMessage(String message);
} 