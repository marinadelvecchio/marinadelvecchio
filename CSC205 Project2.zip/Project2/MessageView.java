/**
 * used to model the MessageView feature of a GUI
 * 
 * @author Marina DelVecchio
 * @version November 2021
 */

// system imports 
import javafx.event.ActionEvent; 
import javafx.event.EventHandler; 
import javafx.geometry.Insets; 
import javafx.geometry.Pos; 
import javafx.scene.Scene; 
import javafx.scene.control.Button; 
import javafx.scene.control.Label; 
import javafx.scene.control.PasswordField; 
import javafx.scene.control.TextField; 
import javafx.scene.layout.GridPane; 
import javafx.scene.layout.HBox; 
import javafx.scene.paint.Color; 
import javafx.scene.text.TextAlignment; 
import javafx.scene.text.Font; 
import javafx.scene.text.FontPosture; 
import javafx.scene.text.FontWeight; 
import javafx.scene.text.Text; 
import javafx.stage.Stage; 

public class MessageView extends Text 
{ 
    //-------------------------------------------------------------------------
    /**
     * the constructor
     * @param initialMessage: a String object
     */
    public MessageView(String initialMessage) 
    { 
        super(initialMessage); 
        setFont(Font.font("Helvetica", FontWeight.BOLD, 16)); 
        setFill(Color.BLUE); 
        setTextAlignment(TextAlignment.LEFT); 
    } 
    //-------------------------------------------------------------------------
    /** 
     * Display ordinary message 
     * @param message: a String object
     */ 
    public void displayMessage(String message) 
    { 
        // display the passed text in blue 
        setFill(Color.BLUE); 
        setText(message); 
    } 
    //-------------------------------------------------------------------------
    /** 
     * Display error message (errors are typically shown in red) 
     * @param message: a String object
     */ 
    public void displayErrorMessage(String message) 
    { 
        // display the passed text in red 
        setFill(Color.RED); 
        setText(message); 
    } 
    //-------------------------------------------------------------------------
    /** 
     * Clear error message 
     */ 
    public void clearErrorMessage() 
    { 
        setText("                           "); 
    } 
} 