/** 
 * models a house to be used when searching for houses with specific criteria 
 *  
 * @author Marina DelVecchio  
 * @version November 2021 
 */ 
public class House { 
    //----------------------------------------------------------------------------
    //input address of house
    private String address;
    
    //---------------------------------------------------------------------------- 
    //input price of house in dollars 
    private int price; 

    //---------------------------------------------------------------------------- 
    //input area of house in square feet  
    private int area; 

    //---------------------------------------------------------------------------- 
    //input number of bedrooms in house 
    private int numBedrooms; 

    //---------------------------------------------------------------------------- 
    /** 
     * The constructor 
     * @param a: A string object representing the address 
     * @param p: an int representing the price 
     * @param ar: an int representing the area 
     * @param nb: an int representing the number of bedrooms 
     */ 
    public House(String a, int p, int ar, int nb) { 
        address = a; 
        price = p; 
        area = ar; 
        numBedrooms = nb; 
    } 
    //---------------------------------------------------------------------------- 
    public String getAddress() { 
        return address; 
    } 
    //---------------------------------------------------------------------------- 
    public int getPrice() { 
        return price; 
    } 
    //---------------------------------------------------------------------------- 
    public int getArea() { 
        return area; 
    } 
    //---------------------------------------------------------------------------- 
    public int getNumBedrooms() { 
        return numBedrooms; 
    } 
    //---------------------------------------------------------------------------- 
    /** 
     * determines if this house satisfies the given criteria 
     * @param c: a Criteria object  
     * @return boolean: returns false if this house does not satisfy criteria,  
     * otherwise returns true 
     */ 
    public boolean satisfies(Criteria c) { 
        if(price<c.getMinimumPrice()||price>c.getMaximumPrice())	 
            return false; 
        else if(area<c.getMinimumArea()||area>c.getMaximumArea()) 
            return false; 
        else if(numBedrooms<c.getMinimumNumberOfBedrooms()||numBedrooms>c.getMaximumNumberOfBedrooms()) 
            return false; 
        return true; 

    } 
    //---------------------------------------------------------------------------- 
    /** 
     * To string method 
     * @return String: this house in a String format listing all attributes 
     */ 
    public String toString() { 
        return("The house located at " +address+" costs $" +price+ ", is "+area+ " square feet, and has " +numBedrooms+ " bedrooms."); 
    } 
} 