/**
 * used to formulate the GUI for the Criteria application
 * 
 * @author Marina DelVecchio
 * @version November 2021
 */

//system imports
import javafx.event.Event;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import java.util.Properties;
import java.util.Vector;

public class CriteriaView extends View {
    //-------------------------------------------------------------------------
    //used to reference the Criteria class
    private Criteria myModel;

    //-------------------------------------------------------------------------
    //GUI components
    private TextField minPrice;
    private TextField maxPrice;
    private TextField minArea;
    private TextField maxArea;
    private TextField minBeds;
    private TextField maxBeds;
    private TextField chosenHome;
    private Button dreamHouse;
    private Button findAnother;
    private Button reset;

    //-------------------------------------------------------------------------
    //For showing error message
    private MessageView statusLog;

    //-------------------------------------------------------------------------
    /**
     * The constructor
     * @param c: a Criteria object
     */
    public CriteriaView(Criteria c) {
        super("CriteriaView");
        myModel=c;

        //create a container for showing the contents
        VBox container = new VBox(10);
        container.setPadding(new Insets(15, 5, 5, 5));

        //create our GUI components, add them to this panel
        container.getChildren().add(createTitle());
        container.getChildren().add(createFormContent());

        //error message area
        container.getChildren().add(createStatusLog(" "));
        getChildren().add(container);
        populateFields();
    }
    //-------------------------------------------------------------------------
    /**
     * method containing the code to create the title of the CriteriaView GUI
     */
    private Node createTitle() {
        HBox container = new HBox();
        container.setAlignment(Pos.CENTER);
        Text titleText = new Text(" Real Estate Listings ");
        titleText.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        titleText.setWrappingWidth(300);
        titleText.setTextAlignment(TextAlignment.CENTER);
        titleText.setFill(Color.BLACK);
        container.getChildren().add(titleText);
        return container;
    }
    //-------------------------------------------------------------------------
    /**
     * method containing the code to create the content of the CriteriaView GUI
     * @return VBox: containing all of the content that is to be placed onto the scene
     */
    private VBox createFormContent() {
        VBox vbox = new VBox(10);
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));
        Text minPriceLabel = new Text("Minimum Price ");
        minPriceLabel.setWrappingWidth(150);
        minPriceLabel.setTextAlignment(TextAlignment.RIGHT);
        grid.add(minPriceLabel, 0, 0);
        Text maxPriceLabel = new Text("Maximum Price ");
        maxPriceLabel.setWrappingWidth(150);
        maxPriceLabel.setTextAlignment(TextAlignment.RIGHT);
        grid.add(maxPriceLabel, 0, 1);
        Text minAreaLabel = new Text("Minimum Area ");
        minAreaLabel.setWrappingWidth(150);
        minAreaLabel.setTextAlignment(TextAlignment.RIGHT);
        grid.add(minAreaLabel, 0, 2);
        Text maxAreaLabel = new Text("Maximum Area ");
        maxAreaLabel.setWrappingWidth(150);
        maxAreaLabel.setTextAlignment(TextAlignment.RIGHT);
        grid.add(maxAreaLabel, 0, 3);
        Text minBedsLabel = new Text("Minimum Beds ");
        minBedsLabel.setWrappingWidth(150);
        minBedsLabel.setTextAlignment(TextAlignment.RIGHT);
        grid.add(minBedsLabel, 0, 4);
        Text maxBedsLabel = new Text("Maximum Beds ");
        maxBedsLabel.setWrappingWidth(150);
        maxBedsLabel.setTextAlignment(TextAlignment.RIGHT);
        grid.add(maxBedsLabel, 0, 5);
        Text chosenHomeLabel = new Text("Chosen Home ");
        chosenHomeLabel.setWrappingWidth(150);
        chosenHomeLabel.setTextAlignment(TextAlignment.RIGHT);
        grid.add(chosenHomeLabel, 0, 7);
        minPrice = new TextField();
        minPrice.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    processAction(e);
                }
            });
        grid.add(minPrice, 1, 0);
        maxPrice = new TextField();
        maxPrice.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    processAction(e);
                }
            });
        grid.add(maxPrice, 1, 1);
        minArea = new TextField();
        minArea.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    processAction(e);
                }
            });
        grid.add(minArea, 1, 2);
        maxArea = new TextField();
        maxArea.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    processAction(e);
                }
            });
        grid.add(maxArea, 1, 3);
        minBeds = new TextField();
        minBeds.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    processAction(e);
                }
            });
        grid.add(minBeds, 1, 4);
        maxBeds = new TextField();
        maxBeds.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    processAction(e);
                }
            });
        grid.add(maxBeds, 1, 5);
        chosenHome = new TextField();
        grid.add(chosenHome, 1, 7);
        dreamHouse = new Button("Find my dream house!");
        dreamHouse.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    clearErrorMessage();
                    processAction(e);
                }
            });
        findAnother = new Button("Not my dream- find me another!");
        findAnother.setDisable(true);
        findAnother.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    clearErrorMessage();
                    myModel.processFindAnother();
                }
            });
        reset = new Button("Reset");
        reset.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    clearErrorMessage();
                    myModel.reset();
                }
            });
        HBox btnContainer = new HBox(100);
        btnContainer.setAlignment(Pos.CENTER);
        btnContainer.getChildren().add(dreamHouse);
        btnContainer.getChildren().add(findAnother);
        btnContainer.getChildren().add(reset);
        vbox.getChildren().add(grid);
        vbox.getChildren().add(btnContainer);
        return vbox;
    }
    //-------------------------------------------------------------------------
    /**
     * method to create a statusLog
     * @param initialMessage: a String object
     * @return MessageView: representing a MessageView object to be displayed
     */
    private MessageView createStatusLog(String initialMessage) {
        statusLog = new MessageView(initialMessage);
        return statusLog;
    }
    //-------------------------------------------------------------------------
    /**
     * method to populate necessary text fields
     */
    public void populateFields() {
        minPrice.setText("");
        maxPrice.setText("");
        minArea.setText("");
        maxArea.setText("");
        minBeds.setText("");
        maxBeds.setText("");
    }
    //-------------------------------------------------------------------------
    /**
     * method to be called when the find my dream home button is clicked in order to start finding a list of dream homes
     * @param evt: an Event object
     */
    public void processAction(Event evt) {
        findAnother.setDisable(false);
        dreamHouse.setDisable(true);
        clearErrorMessage();
        String minPriceE = minPrice.getText();
        String maxPriceE = maxPrice.getText();
        String minAreaE = minArea.getText();
        String maxAreaE = maxArea.getText();
        String minBedsE = minBeds.getText();
        String maxBedsE = maxBeds.getText();

        try {
            processHouse(minPriceE, maxPriceE, minAreaE, maxAreaE, minBedsE, maxBedsE);
        }
        catch (Exception ex) {
            displayErrorMessage("Error in processing criteria");
        }
    }
    //-------------------------------------------------------------------------
    /**
     * a method to continue the process of creating a list of dream homes by creating a Properties object
     * @param minP: a String object representing the minimum price in String format
     * @param maxP: a String object representing the maximum price in String format
     * @param minA: a String object representing the minimum area in String format
     * @param maxA: a String object representing the maximum area in String format
     * @param minB: a String object representing the minimum bedrooms in String format
     * @param maxB: a String object representing the maximum bedrooms in String format
     */
    private void processHouse(String minP, String maxP, String minA, String maxA, String minB, String maxB) {
        Properties props = new Properties();
        props.setProperty("MinPrice", minP);
        props.setProperty("MaxPrice", maxP);
        props.setProperty("MinArea", minA);
        props.setProperty("MaxArea", maxA);
        props.setProperty("MinBeds", minB);
        props.setProperty("MaxBeds", maxB);
        myModel.processCriteria(props);
    }
    //-------------------------------------------------------------------------
    /**
     * method to update the chosenHome textfield
     * @param key: a String object representing the key of the property
     * @param value: an Object representing the value matching the key
     */
    public void updateState(String key, Object value) {
        if(key.equals("ChosenHome")==true) {
            String val = (String)value;
            chosenHome.setText(val);
        }
    }
    //-------------------------------------------------------------------------
    /**
     * method to display a given error message
     * @param message: a String object
     */
    public void displayErrorMessage(String message) {
        statusLog.displayErrorMessage(message);
    }
    //-------------------------------------------------------------------------
    /**
     * method to clear the error message field
     */
    public void clearErrorMessage() {
        statusLog.clearErrorMessage();
    }
}
 