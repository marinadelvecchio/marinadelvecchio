/** 
 * models a criteria to be used when searching for a house with specific features 
 *  
 * @author Marina DelVecchio  
 * @version November 2021 
 */ 

//system imports
import javafx.stage.Stage;
import javafx.scene.Scene;
import java.util.Properties;
import java.util.*;

public class Criteria { 
    //---------------------------------------------------------------------------- 
    //input minimum price in dollars any house can be 
    private int minimumPrice; 
    
    //---------------------------------------------------------------------------- 
    //input maximum price in dollars any house can be 
    private int maximumPrice; 
    
    //---------------------------------------------------------------------------- 
    //input minimum area in square feet any house can have 
    private int minimumArea; 
    
    //---------------------------------------------------------------------------- 
    //input maximum area in square feet any house can have 
    private int maximumArea; 
    
    //---------------------------------------------------------------------------- 
    //input minimum number of bedrooms any house can have 
    private int minimumNumberOfBedrooms; 
    
    //---------------------------------------------------------------------------- 
    //input maximum number of bedrooms any house can have 
    private int maximumNumberOfBedrooms; 
    
    //----------------------------------------------------------------------------
    //list of available houses from houses.txt
    private HouseList availableHouses;
    
    //----------------------------------------------------------------------------
    //ArrayList of houses that match the entered criteria
    private ArrayList<House> dreams;
    
    //----------------------------------------------------------------------------
    //index of currently displayed house
    private int curIn=-1;
    
    //-------------------------------------------------------------------------
    //GUI Components
    private Stage myStage;
    private View criteriaView;
    private Scene currentScene;
    private String transactionErrorMessage="";
    
    //----------------------------------------------------------------------------
    /**
     * The default constructor 
     */
    public Criteria() {
        myStage = MainStageContainer.getInstance();
        createAndShowCriteriaView();
    }
    //---------------------------------------------------------------------------- 
    /** 
     * The parameterized constructor 
     * @param minP: an int representing the minimum price 
     * @param maxP: an int representing the maximum price 
     * @param minA: an int representing the minimum area 
     * @param maxA: an int representing the maximum area 
     * @param minNB: an int representing the minimum number of bedrooms 
     * @param maxNB: an int representing the maximum number of bedrooms 
     */ 
    public Criteria(int minP, int maxP, int minA, int maxA, int minNB, int maxNB) 	{ 
        minimumPrice = minP; 
        maximumPrice = maxP; 
        minimumArea = minA; 
        maximumArea = maxA; 
        minimumNumberOfBedrooms = minNB; 
        maximumNumberOfBedrooms = maxNB; 
    } 
    //---------------------------------------------------------------------------- 
    /**
     * method to process input values when find my dream house button is clicked
     * @param props: a Properties object
     */
    public void processCriteria(Properties props) {
        int minPrice = 0;
        int minArea = 0;
        int minBedrooms = 0;
        int maxPrice = Integer.MAX_VALUE;
        int maxArea = Integer.MAX_VALUE;
        int maxBedrooms = Integer.MAX_VALUE;
        String minPS = props.getProperty("MinPrice");
        String maxPS = props.getProperty("MaxPrice");
        String minAS = props.getProperty("MinArea");
        String maxAS = props.getProperty("MaxArea");
        String minBS = props.getProperty("MinBeds");
        String maxBS = props.getProperty("MaxBeds");
        
        if(minPS.length()!=0) 
            minPrice = Integer.parseInt(minPS);
        if(maxPS.length()!=0) 
            maxPrice = Integer.parseInt(maxPS);
        if(minAS.length()!=0)
            minArea = Integer.parseInt(minAS);
        if(maxAS.length()!=0) 
            maxArea = Integer.parseInt(maxAS);
        if(minBS.length()!=0)
            minBedrooms = Integer.parseInt(minBS);
        if(maxBS.length()!=0)
            maxBedrooms = Integer.parseInt(maxBS);
        
        availableHouses = new HouseList("houses.txt");
        dreams = availableHouses.getHouses(new Criteria(minPrice, maxPrice, minArea, maxArea, minBedrooms, maxBedrooms));
        processFindAnother();
    }
    //----------------------------------------------------------------------------
    /**
     * method to determine which random house should be displayed from dreams 
     * 
     */
    public void processFindAnother() {
        if(curIn!=-1)
            dreams.remove(curIn);
        if(dreams.size()!=0) {
            curIn = (int) (Math.random()*(dreams.size()-1));
            criteriaView.updateState("ChosenHome", ""+dreams.get(curIn).getAddress());
        }
        else {
            criteriaView.displayErrorMessage("No more available houses!");
        }
    }
    //----------------------------------------------------------------------------
    /**
     * method to reset all GUI and non-GUI fields 
     */
    public void reset() {
        dreams.clear();
        createAndShowCriteriaView();
    }
    //----------------------------------------------------------------------------
    /**
     * method to display CriteriaView
     */
    private void createAndShowCriteriaView() {
        // create our new view 
        criteriaView = new CriteriaView (this);  
        currentScene = new Scene(criteriaView); 
        // make the view visible by installing it into the stage 
        swapToView(currentScene);
    }
    //----------------------------------------------------------------------------
    /**
     * method to display a new scene
     * @param newScene: a Scene object
     */
    public void swapToView(Scene newScene) 
    { 
        if (newScene == null) 
        { 
            System.out.println 
            ("Invoice.swapToView(): Missing view for display"); 
            return; 
        } 

        // SWAP THE SCENE ON THE STAGE 
        myStage.setScene(newScene); 
        // RE-SIZE STAGE TO FIT NEW SCENE SIZE 
        myStage.sizeToScene();					 
        //Place in center again 
        WindowPosition.placeCenter(myStage); 
    }
    //----------------------------------------------------------------------------     
    public int getMinimumPrice() { 
        return minimumPrice; 
    } 
    //---------------------------------------------------------------------------- 
    public int getMaximumPrice() { 
        return maximumPrice; 
    } 
    //---------------------------------------------------------------------------- 
    public int getMinimumArea() { 
        return minimumArea; 
    } 
    //---------------------------------------------------------------------------- 
    public int getMaximumArea() { 
        return maximumArea; 
    } 
    //---------------------------------------------------------------------------- 
    public int getMinimumNumberOfBedrooms() { 
        return minimumNumberOfBedrooms; 
    } 
    //---------------------------------------------------------------------------- 
    public int getMaximumNumberOfBedrooms() { 
        return maximumNumberOfBedrooms; 
    } 
} 