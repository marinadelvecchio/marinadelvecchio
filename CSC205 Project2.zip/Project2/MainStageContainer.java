/**
 * The main stage for the Brockport GUI applications. All scenes are inside this one stage only. 
 * 
 * @author Marina DelVecchio
 * @version November 2021
 */

// system imports 
import javafx.stage.Stage; 

public class MainStageContainer 
{ 
    //-------------------------------------------------------------------------
    // data members 
    private static Stage myInstance = null; 

    //------------------------------------------------------------------------- 
    /**
     * default constructor
     */
    private MainStageContainer () 
    { 
    } 
    //---------------------------------------------------------- 
    public static Stage getInstance() 
    { 
        return myInstance;  
    } 
    //----------------------------------------------------------- 
    public static void setStage(Stage st, String title) 
    { 
        myInstance = st; 
        myInstance.setTitle(title); 
        myInstance.setResizable(false); 
    } 
} 